// pages/CreatMap/CreatMap.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    MapList:[],
    MapChosen:0,
  },
  onLoad: function(options){
    this.setData({
      MapList:app.globalData.MapList
    })
  },
  handleItemTap(e)
  {
    const {index}=e.currentTarget.dataset;
    this.setData({
      MapChosen:index
    })
    wx.navigateTo({
      url: '../Map/Map?MapChosen=index'
    })
  }
})