// pages/DataDetail/DataDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      DeviceList_Sorted:[
        {
            Rank:'0',
            name:'a',
        },
        {
          Rank:'1',
          name:'b',
      }
      ],
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url:  "",
      data:{
        MatchChosen:options.datachosen
      },
      success(res){
        this.setData({
          DeviceList_Sorted:res.DeviceLis
        }) 
      }
    })
    /* let request = wx.request({
      url: '',
      data: {},
      header: {'content-type':'application/json'},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: (result)=>{
        
      },
      fail: ()=>{},
      complete: ()=>{}
    }); 请求设备列表——已经排序的*/
  },
  HandleTap(e){
    var d=e.currentTarget.dataset.num
    wx.navigateTo({
      url: '../DataDetail/DataDetail?devicechosen='+d
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})