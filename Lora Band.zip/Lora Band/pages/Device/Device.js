var app=getApp()
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
      temp:'',
      Chosen:'Null',
      Input: '名称',
      DeviceList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
        DeviceList:app.globalData.DeviceList
    })
  },
  bindShowMsg(e) {
    var num = e.currentTarget.dataset.num
       this.setData({
           Chosen:num
       })
  },
  mySelect(e) {
      var name = e.currentTarget.dataset.num
      this.setData({
          Input: name,
          Chosen: ''
      })
  },
  queren(e) {
      var index=e.currentTarget.dataset.index
      var up = "DeviceList[" + index + "].name";
    this.setData({
        [up]: this.data.temp
    })
    
  },
  Input(e){
    this.setData({
        temp:e.detail.value
      })
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
